$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$assets = Join-Path $root "assets"
$icoPath = Join-Path $assets "weread.ico"

New-Item -ItemType Directory -Force -Path $assets | Out-Null
Add-Type -AssemblyName System.Drawing

$size = 64
$bitmap = New-Object System.Drawing.Bitmap($size, $size)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.Clear([System.Drawing.Color]::Transparent)

$bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
  (New-Object System.Drawing.Rectangle(0, 0, $size, $size)),
  [System.Drawing.Color]::FromArgb(31, 155, 87),
  [System.Drawing.Color]::FromArgb(12, 99, 64),
  45
)
$graphics.FillEllipse($bg, 4, 4, 56, 56)

$bookBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(248, 245, 236))
$shadowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(60, 0, 0, 0))
$graphics.FillRectangle($shadowBrush, 19, 18, 28, 34)
$graphics.FillRectangle($bookBrush, 17, 16, 28, 34)

$linePen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(38, 122, 75), 2)
$graphics.DrawLine($linePen, 31, 17, 31, 49)
$graphics.DrawLine($linePen, 22, 25, 28, 25)
$graphics.DrawLine($linePen, 22, 32, 28, 32)
$graphics.DrawLine($linePen, 34, 25, 40, 25)
$graphics.DrawLine($linePen, 34, 32, 40, 32)

$stream = New-Object System.IO.MemoryStream
$bitmap.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png)
$pngBytes = $stream.ToArray()
$stream.Dispose()

$file = [System.IO.File]::Open($icoPath, [System.IO.FileMode]::Create)
$writer = New-Object System.IO.BinaryWriter($file)
$writer.Write([UInt16]0)
$writer.Write([UInt16]1)
$writer.Write([UInt16]1)
$writer.Write([byte]$size)
$writer.Write([byte]$size)
$writer.Write([byte]0)
$writer.Write([byte]0)
$writer.Write([UInt16]1)
$writer.Write([UInt16]32)
$writer.Write([UInt32]$pngBytes.Length)
$writer.Write([UInt32]22)
$writer.Write($pngBytes)
$writer.Close()
$file.Close()

$graphics.Dispose()
$bitmap.Dispose()

Write-Host $icoPath
