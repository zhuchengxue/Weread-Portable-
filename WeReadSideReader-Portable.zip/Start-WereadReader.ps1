param(
  [string]$Url = "https://weread.qq.com/",
  [int]$Width = 390,
  [int]$Height = 1040
)

$ErrorActionPreference = "Stop"

$App = [ordered]@{
  Root = Split-Path -Parent $MyInvocation.MyCommand.Path
  HomeUrl = "https://weread.qq.com/"
  MinWidth = 240
  MinHeight = 360
  CollapseSize = 8
  AutoHideDelayMs = 500
  AutoHideCooldownMs = 900
}
$App.SettingsPath = Join-Path $App.Root "settings.json"
$App.ProfilePath = Join-Path $App.Root "profile"
$App.IconPath = Join-Path $App.Root "assets\weread.ico"
$App.LibPath = Join-Path $App.Root "lib"
$App.PackageRoot = Join-Path $App.Root "packages\Microsoft.Web.WebView2"

function Find-PackageFile($filter, $pathPattern) {
  Get-ChildItem -Path $App.PackageRoot -Recurse -Filter $filter -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match $pathPattern } |
    Select-Object -First 1
}

$winFormsDll = Get-Item -LiteralPath (Join-Path $App.LibPath "Microsoft.Web.WebView2.WinForms.dll") -ErrorAction SilentlyContinue
$coreDll = Get-Item -LiteralPath (Join-Path $App.LibPath "Microsoft.Web.WebView2.Core.dll") -ErrorAction SilentlyContinue
$nativeLoader = Get-Item -LiteralPath (Join-Path $App.LibPath "WebView2Loader.dll") -ErrorAction SilentlyContinue

if (-not $winFormsDll) { $winFormsDll = Find-PackageFile "Microsoft.Web.WebView2.WinForms.dll" "\\lib\\net462\\" }
if (-not $coreDll) { $coreDll = Find-PackageFile "Microsoft.Web.WebView2.Core.dll" "\\lib\\net462\\" }
if (-not $nativeLoader) { $nativeLoader = Find-PackageFile "WebView2Loader.dll" "\\runtimes\\win-x64\\native\\" }

if (-not $winFormsDll -or -not $coreDll -or -not $nativeLoader) {
  throw "Missing WebView2 dependency. Run Install-Dependencies.ps1 first."
}

$env:PATH = "$(Split-Path -Parent $nativeLoader.FullName);$env:PATH"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -Path $coreDll.FullName
Add-Type -Path $winFormsDll.FullName

Add-Type -ReferencedAssemblies "System.Windows.Forms","System.Drawing" -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class HotkeyForm : Form
{
    public event EventHandler HotkeyPressed;

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0312)
        {
            EventHandler handler = HotkeyPressed;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }
        base.WndProc(ref m);
    }
}

public static class HotkeyNative
{
    [DllImport("user32.dll")]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll")]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
}
"@

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

function Load-Settings {
  if (-not (Test-Path $App.SettingsPath)) {
    return [pscustomobject]@{}
  }

  try {
    return Get-Content -LiteralPath $App.SettingsPath -Raw | ConvertFrom-Json
  } catch {
    return [pscustomobject]@{}
  }
}

function Test-Bounds($bounds) {
  return $bounds.Width -ge $App.MinWidth -and $bounds.Height -ge $App.MinHeight
}

function Clamp-WindowToWorkArea($form) {
  $workArea = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
  if ($form.Width -gt $workArea.Width) { $form.Width = $workArea.Width }
  if ($form.Height -gt $workArea.Height) { $form.Height = $workArea.Height }
  if ($form.Left -lt $workArea.Left) { $form.Left = $workArea.Left }
  if ($form.Top -lt $workArea.Top) { $form.Top = $workArea.Top }
  if ($form.Right -gt $workArea.Right) { $form.Left = $workArea.Right - $form.Width }
  if ($form.Bottom -gt $workArea.Bottom) { $form.Top = $workArea.Bottom - $form.Height }
}

$settings = Load-Settings
$startUrl = if ($settings.CurrentUrl) { [string]$settings.CurrentUrl } else { $Url }
$screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$savedWidth = if ($settings.Width -and [int]$settings.Width -ge $App.MinWidth) { [int]$settings.Width } else { $Width }
$savedHeight = if ($settings.Height -and [int]$settings.Height -ge $App.MinHeight) { [int]$settings.Height } else { $Height }

$script:zoomFactor = if ($settings.ZoomFactor -ne $null) { [double]$settings.ZoomFactor } else { 1.0 }
$script:autoHideEnabled = if ($settings.AutoHideEnabled -ne $null) { [bool]$settings.AutoHideEnabled } else { $false }
$script:currentUrl = $startUrl
$script:isCollapsed = $false
$script:isTransitioning = $false
$script:isContentFullscreen = $false
$script:settingsReady = $false
$script:lastAutoHideAt = [DateTime]::MinValue
$script:saveSettingsTimer = $null

$form = New-Object HotkeyForm
$form.Text = "WeRead"
$form.StartPosition = "Manual"
$form.Width = $savedWidth
$form.Height = [Math]::Min($savedHeight, $screen.Height)
$form.Left = if ($settings.Left -ne $null) { [int]$settings.Left } else { $screen.Right - $form.Width }
$form.Top = if ($settings.Top -ne $null) { [int]$settings.Top } else { $screen.Top }
$form.MinimumSize = New-Object System.Drawing.Size(320, 520)
$form.TopMost = $false
$form.ShowInTaskbar = $true
$form.KeyPreview = $true
if (Test-Path $App.IconPath) {
  $form.Icon = New-Object System.Drawing.Icon($App.IconPath)
}
Clamp-WindowToWorkArea $form

$script:normalMinimumSize = $form.MinimumSize
$script:expandedBounds = $form.Bounds
$script:preCollapseBorderStyle = $form.FormBorderStyle
$script:preFullscreenBounds = $null
$script:preFullscreenBorderStyle = $form.FormBorderStyle
$script:preFullscreenWindowState = $form.WindowState

function Save-Settings {
  if (-not $script:settingsReady -or -not $form -or $script:isCollapsed -or $script:isTransitioning) {
    return
  }

  $bounds = if ($script:isContentFullscreen -and $script:preFullscreenBounds) {
    $script:preFullscreenBounds
  } else {
    $form.Bounds
  }
  if (-not (Test-Bounds $bounds)) {
    return
  }

  [pscustomobject]@{
    Width = $bounds.Width
    Height = $bounds.Height
    Left = $bounds.Left
    Top = $bounds.Top
    ZoomFactor = $script:zoomFactor
    AutoHideEnabled = $script:autoHideEnabled
    CurrentUrl = $script:currentUrl
  } | ConvertTo-Json | Set-Content -LiteralPath $App.SettingsPath -Encoding UTF8
}

function Save-SettingsSoon {
  if ($script:saveSettingsTimer) {
    $script:saveSettingsTimer.Stop()
    $script:saveSettingsTimer.Start()
  } else {
    Save-Settings
  }
}

function New-ToolbarButton($text, $width) {
  $button = New-Object System.Windows.Forms.Button
  $button.Text = $text
  $button.Width = $width
  $button.Height = 26
  $button.Margin = New-Object System.Windows.Forms.Padding(3, 5, 3, 3)
  return $button
}

$toolbar = New-Object System.Windows.Forms.FlowLayoutPanel
$toolbar.Dock = "Top"
$toolbar.Height = 36
$toolbar.WrapContents = $false
$toolbar.AutoScroll = $false
$toolbar.BackColor = [System.Drawing.Color]::FromArgb(248, 248, 248)

$btnBack = New-ToolbarButton "Back" 45
$btnHome = New-ToolbarButton "Home" 48
$btnReload = New-ToolbarButton "Load" 46
$btnSmaller = New-ToolbarButton "A-" 35
$btnLarger = New-ToolbarButton "A+" 35
$btnAuto = New-ToolbarButton ($(if ($script:autoHideEnabled) { "Auto*" } else { "Auto" })) 48
$btnFull = New-ToolbarButton "Full" 45
$toolbar.Controls.AddRange(@($btnBack, $btnHome, $btnReload, $btnSmaller, $btnLarger, $btnAuto, $btnFull))

$webview = New-Object Microsoft.Web.WebView2.WinForms.WebView2
$webview.Dock = "Fill"
$webview.ZoomFactor = $script:zoomFactor
$webview.CreationProperties = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
$webview.CreationProperties.UserDataFolder = $App.ProfilePath

$form.Controls.Add($webview)
$form.Controls.Add($toolbar)

function Toggle-ReaderWindow {
  if ($form.Visible) {
    $form.Hide()
  } else {
    $form.Show()
    $form.Activate()
  }
}

function Navigate-Home {
  if ($webview.CoreWebView2) {
    $script:currentUrl = $App.HomeUrl
    Save-Settings
    $webview.CoreWebView2.Navigate($App.HomeUrl)
  }
}

function Remember-CurrentUrl {
  if (-not $webview.CoreWebView2) { return }
  $source = [string]$webview.CoreWebView2.Source
  if ($source -and $source -match "^https://(weread|i\.weread)\.qq\.com/") {
    $script:currentUrl = $source
    Save-SettingsSoon
  }
}

function Set-ReaderZoom([double]$value) {
  $script:zoomFactor = [Math]::Max(0.8, [Math]::Min(1.8, $value))
  if ($webview) {
    $webview.ZoomFactor = $script:zoomFactor
  }
  Save-Settings
}

function Get-DockedEdge {
  $workArea = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
  if ([Math]::Abs($form.Right - $workArea.Right) -le 16) { return "Right" }
  if ([Math]::Abs($form.Left - $workArea.Left) -le 16) { return "Left" }
  if ([Math]::Abs($form.Top - $workArea.Top) -le 16) { return "Top" }
  return ""
}

function Pointer-InForm {
  return $form.Bounds.Contains([System.Windows.Forms.Cursor]::Position)
}

function Pointer-NearTopTrigger {
  $point = [System.Windows.Forms.Cursor]::Position
  $workArea = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
  return $point.Y -ge $workArea.Top -and
    $point.Y -le ($workArea.Top + 18) -and
    $point.X -ge $form.Left -and
    $point.X -le $form.Right
}

function Collapse-ToEdge {
  $edge = Get-DockedEdge
  if (-not $script:autoHideEnabled -or $script:isCollapsed -or -not $edge) { return }
  if (((Get-Date) - $script:lastAutoHideAt).TotalMilliseconds -lt $App.AutoHideCooldownMs) { return }

  $script:expandedBounds = $form.Bounds
  $workArea = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
  $script:isTransitioning = $true
  $script:isCollapsed = $true
  $script:preCollapseBorderStyle = $form.FormBorderStyle
  $form.MinimumSize = New-Object System.Drawing.Size(1, 1)
  $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None

  if ($edge -eq "Right") {
    $form.Width = $App.CollapseSize
    $form.Height = [Math]::Min($script:expandedBounds.Height, $workArea.Height)
    $form.Left = $workArea.Right - $App.CollapseSize
    $form.Top = [Math]::Max($workArea.Top, [Math]::Min($script:expandedBounds.Top, $workArea.Bottom - $form.Height))
  } elseif ($edge -eq "Left") {
    $form.Width = $App.CollapseSize
    $form.Height = [Math]::Min($script:expandedBounds.Height, $workArea.Height)
    $form.Left = $workArea.Left
    $form.Top = [Math]::Max($workArea.Top, [Math]::Min($script:expandedBounds.Top, $workArea.Bottom - $form.Height))
  } elseif ($edge -eq "Top") {
    $form.Width = [Math]::Min($script:expandedBounds.Width, $workArea.Width)
    $form.Height = $App.CollapseSize
    $form.Left = [Math]::Max($workArea.Left, [Math]::Min($script:expandedBounds.Left, $workArea.Right - $form.Width))
    $form.Top = $workArea.Top
  }

  $form.TopMost = $true
  $script:isTransitioning = $false
  $script:lastAutoHideAt = Get-Date
}

function Expand-FromEdge {
  if (-not $script:isCollapsed) { return }
  if (((Get-Date) - $script:lastAutoHideAt).TotalMilliseconds -lt 180) { return }

  $script:isTransitioning = $true
  $script:isCollapsed = $false
  $form.MinimumSize = $script:normalMinimumSize
  $form.FormBorderStyle = $script:preCollapseBorderStyle
  $form.Bounds = $script:expandedBounds
  $form.TopMost = $false
  $form.Activate()
  $script:isTransitioning = $false
  $script:lastAutoHideAt = Get-Date
}

function Toggle-AutoHide {
  $script:autoHideEnabled = -not $script:autoHideEnabled
  $btnAuto.Text = if ($script:autoHideEnabled) { "Auto*" } else { "Auto" }
  if (-not $script:autoHideEnabled -and $script:isCollapsed) {
    Expand-FromEdge
  }
  Save-Settings
}

function Toggle-ContentFullscreen {
  if (-not $script:isContentFullscreen) {
    if ($script:isCollapsed) { Expand-FromEdge }
    $script:preFullscreenBounds = $form.Bounds
    $script:preFullscreenBorderStyle = $form.FormBorderStyle
    $script:preFullscreenWindowState = $form.WindowState
    $script:isContentFullscreen = $true
    $toolbar.Visible = $false
    $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Bounds = $script:preFullscreenBounds
    return
  }

  $script:isContentFullscreen = $false
  $toolbar.Visible = $true
  $form.FormBorderStyle = $script:preFullscreenBorderStyle
  $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
  if ($script:preFullscreenBounds) {
    $form.Bounds = $script:preFullscreenBounds
  }
  Save-Settings
}

function Initialize-WebView {
  $scheduler = [System.Threading.Tasks.TaskScheduler]::FromCurrentSynchronizationContext()
  $callback = [System.Action[System.Threading.Tasks.Task]]{
    param($task)
    if ($task.IsFaulted) {
      [System.Windows.Forms.MessageBox]::Show(
        $task.Exception.GetBaseException().Message,
        "WebView2 init failed",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
      ) | Out-Null
      return
    }

    $webview.CoreWebView2.Settings.AreDefaultContextMenusEnabled = $true
    $webview.CoreWebView2.Settings.AreDevToolsEnabled = $false
    $webview.CoreWebView2.add_NavigationCompleted({ Remember-CurrentUrl })
    Set-ReaderZoom $script:zoomFactor
    $webview.CoreWebView2.Navigate($script:currentUrl)
  }

  $webview.EnsureCoreWebView2Async($null).ContinueWith($callback, $scheduler) | Out-Null
}

$btnBack.Add_Click({ if ($webview.CanGoBack) { $webview.GoBack() } })
$btnHome.Add_Click({ Navigate-Home })
$btnReload.Add_Click({ $webview.Reload() })
$btnSmaller.Add_Click({ Set-ReaderZoom ($script:zoomFactor - 0.1) })
$btnLarger.Add_Click({ Set-ReaderZoom ($script:zoomFactor + 0.1) })
$btnAuto.Add_Click({ Toggle-AutoHide })
$btnFull.Add_Click({ Toggle-ContentFullscreen })

$form.Add_KeyDown({
  param($sender, $event)
  if ($event.Control -and $event.Shift -and $event.KeyCode -eq [System.Windows.Forms.Keys]::Y) {
    Toggle-ReaderWindow
    $event.Handled = $true
  } elseif ($event.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
    if ($script:isContentFullscreen) { Toggle-ContentFullscreen } else { $form.Hide() }
    $event.Handled = $true
  } elseif ($event.KeyCode -eq [System.Windows.Forms.Keys]::F11) {
    Toggle-ContentFullscreen
    $event.Handled = $true
  }
})

$autoHideTimer = New-Object System.Windows.Forms.Timer
$autoHideTimer.Interval = $App.AutoHideDelayMs
$autoHideTimer.Add_Tick({
  if ($script:isContentFullscreen -and $form.Visible -and -not $script:isCollapsed) {
    $cursor = [System.Windows.Forms.Cursor]::Position
    if ($cursor.X -ge $form.Left -and $cursor.X -le $form.Right -and $cursor.Y -ge $form.Top -and $cursor.Y -le ($form.Top + 8)) {
      $toolbar.Visible = $true
    } elseif ($toolbar.Visible -and $cursor.Y -gt ($form.Top + 44)) {
      $toolbar.Visible = $false
    }
  }

  if (-not $script:autoHideEnabled -or -not $form.Visible) { return }
  if ($script:isCollapsed) {
    if (Pointer-InForm) { Expand-FromEdge }
    return
  }

  $edge = Get-DockedEdge
  if ($edge -eq "Top" -and (Pointer-NearTopTrigger)) { return }
  if (-not (Pointer-InForm) -and $edge) { Collapse-ToEdge }
})
$autoHideTimer.Start()

$script:saveSettingsTimer = New-Object System.Windows.Forms.Timer
$script:saveSettingsTimer.Interval = 500
$script:saveSettingsTimer.Add_Tick({
  $script:saveSettingsTimer.Stop()
  Save-Settings
})

$form.Add_Move({
  if (-not $script:isCollapsed -and -not $script:isTransitioning) {
    $script:expandedBounds = $form.Bounds
    Save-SettingsSoon
  }
})
$form.Add_Resize({
  if (-not $script:isCollapsed -and -not $script:isTransitioning) {
    $script:expandedBounds = $form.Bounds
    Save-SettingsSoon
  }
})
$form.Add_MouseEnter({ Expand-FromEdge })
$toolbar.Add_MouseEnter({ Expand-FromEdge })
$webview.Add_MouseEnter({ Expand-FromEdge })

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Text = "WeRead"
$notify.Icon = if (Test-Path $App.IconPath) { New-Object System.Drawing.Icon($App.IconPath) } else { [System.Drawing.SystemIcons]::Application }
$notify.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$showItem = $menu.Items.Add("Show / Hide")
$homeItem = $menu.Items.Add("Home")
$exitItem = $menu.Items.Add("Exit")
$notify.ContextMenuStrip = $menu

$notify.Add_DoubleClick({ Toggle-ReaderWindow })
$showItem.Add_Click({ Toggle-ReaderWindow })
$homeItem.Add_Click({
  $form.Show()
  $form.Activate()
  Navigate-Home
})
$exitItem.Add_Click({
  $notify.Visible = $false
  $notify.Dispose()
  $form.Close()
})

$hotkeyId = 1
$modControlShift = 0x0002 -bor 0x0004
$vkY = [int][System.Windows.Forms.Keys]::Y

$form.Add_FormClosing({
  [HotkeyNative]::UnregisterHotKey($form.Handle, $hotkeyId) | Out-Null
  $autoHideTimer.Stop()
  $autoHideTimer.Dispose()
  if ($script:saveSettingsTimer) {
    $script:saveSettingsTimer.Stop()
    $script:saveSettingsTimer.Dispose()
  }
  Save-Settings
  $notify.Visible = $false
  $notify.Dispose()
})

$form.Add_Shown({
  $script:settingsReady = $true
  [HotkeyNative]::RegisterHotKey($form.Handle, $hotkeyId, $modControlShift, $vkY) | Out-Null
  Initialize-WebView
  Save-Settings
})

$form.add_HotkeyPressed({ Toggle-ReaderWindow })

[System.Windows.Forms.Application]::Run($form)
